function validate(){
var username=document.getElementById("name")
var password=document.getElementById("password")
if(username.value=='' &&  password.value=='') {
alert("Invalid input!!!")
}
else
    alert("validation complete")  
}