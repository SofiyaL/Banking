var MainController=(function(){
    document.getElementById('icon').addEventListener('click',()=>{
        ctrlAdd();
    }
    )
    document.getElementById('am2').addEventListener('keypress',(event)=>{
        if(event.keyCode===13)
        ctrlAdd();
    })
    var ctrlAdd=function(){
        var inputdata=UIcontroller.inputData()
        var dispdata=UIcontroller.displayData(inputdata.type,inputdata.description,inputdata.amount)
        var calculate=transaction.addItem(inputdata.type,inputdata.description,inputdata.amount)
        console.log(calculate.balance)
        console.log(calculate.dep)
        console.log(calculate.withd)
            document.getElementById('am1').innerHTML=calculate.balance
            document.getElementById('d1').innerHTML= calculate.dep
            document.getElementById('w1').innerHTML= calculate.withd
    }
}(UIcontroller,transaction));

var UIcontroller=(function(){
    return {
        inputData:function(){
            return{
                type:document.getElementById('sel').value,
                description:document.getElementById('des').value,
                amount:Number(document.getElementById('am2').value),
            };
        },
        displayData:function(type,description,amount){
            array=[type,description,amount]
            var string= array.toString();
            if(type=='deposit'){
            let newBal=document.createElement('p')
            newBal.textContent=string;
            document.getElementById('dis').appendChild(newBal)
                }
                else {
                    let newBal=document.createElement('p')
                    newBal.textContent=string;
                    document.getElementById('wis').appendChild(newBal)
                }
                
            }
    };
    
}());


var balance=0
var dep=0
var withd=0
    var transaction=(function(){
            return{
                addItem:function(type,description,amount)
                {
    if(type=='deposit')
    {
        balance=balance+amount
        dep=dep+amount
    }
    else{
        balance=balance-amount
        withd=withd+amount
        }
        return {balance,dep,withd}
    }
} 
}());

